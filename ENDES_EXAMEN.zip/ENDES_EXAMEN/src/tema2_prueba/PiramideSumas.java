package tema2_prueba;

import java.util.Scanner;

public class PiramideSumas {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String resp;

		do {
			int numero = leerEntero(sc, "Introduzca un número: "); // RGC20251031 - No estaba bien cerrado.
			while (numero < 0 || numero > 20) {// RGC20251031 OR en vez de AND
				numero = leerEntero(sc, "**Valor fuera de rango** Introduzca un número entre 0 y 20: ");
			}

			System.out.println("\nSu pirámide de sumas es la siguiente:\n" + piramide(numero));

			System.out.print("¿Quiere hacer otra pirámide? (s/n) "); 
			resp = sc.next().trim().toUpperCase(); // RGC20251031 - Duplicación de la variables.

		} while (resp.equals("S"));// RGC20251031 - Error sintactico ");" Falta la )
		borrarConsola();
		System.out.println("¡¡¡PROGRAMA FINALIZADO!!!");

		sc.close();
	}

	private static int leerEntero(Scanner sc, String mensaje) {
		System.out.print(mensaje);
		while (!sc.hasNextInt()) {
			System.out.print("**Valor no válido** Introduzca un número entero: ");
			sc.next();
		}
		return sc.nextInt();
	}

	public static void borrarConsola() {
		for (int i = 0; i < 50; i++) { // RGC20251031 - es una , en vez de ;
			System.out.println();
		}
	}

	public static String piramide(int numero) {
		String res = "";
		int n = numero; 

		while (n >= 0) { // RGC20251031 Debe ser mayor para que pueda ejecutar la piramide.
			int cont = 1;
			int total = 0;
			res += n + " => 0 ";
			
			while (cont <= n) {//RGC20251031 No contaba con las llaves.
				
				res += "+ " + cont + " ";
				total += cont;
				cont +=1;
			}
			if (n != 0) {
				res += "= " + total ; 
			}	
			res += "\n";
			n -= 1;
		}
		
		return res; // RGC20251031 - resultado no esta declarado anteriormente, y no aporta nada.
	}

}
